# Northlane website

En statisk nettside for Northlane. Nettsiden bruker vanlig HTML, CSS og
JavaScript og trenger ingen bygging eller installasjon.

## Publiser med GitHub Pages

1. Opprett et nytt repository på GitHub, for eksempel `northlane-website`.
2. Last opp alle filene i denne mappen direkte til roten av repositoryet.
3. Åpne `Settings` i repositoryet og velg `Pages`.
4. Under `Build and deployment`, velg `Deploy from a branch`.
5. Velg branchen `main`, mappen `/(root)`, og trykk `Save`.

GitHub publiserer deretter siden på en adresse som ligner:

`https://brukernavn.github.io/northlane-website/`

GitHub sin offisielle veiledning:
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Eget domene

Et eget domene som `northlane.no` kan kobles til under `Settings` og `Pages`
etter at nettsiden er publisert. Følg GitHub sin domeneveiledning for DNS-
innstillingene:

https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/about-custom-domains-and-github-pages

## Filer

- `index.html` - innholdet på nettsiden
- `styles.css` - design og mobiltilpasning
- `script.js` - mobilmeny og enkle animasjoner
- `logo.png` - Northlane-logoen
- `.nojekyll` - ber GitHub publisere filene direkte
